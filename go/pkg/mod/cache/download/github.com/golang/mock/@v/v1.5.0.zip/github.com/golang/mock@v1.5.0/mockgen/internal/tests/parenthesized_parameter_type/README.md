# Parenthesized Parameter Type

Test for [Issue#416](https://github.com/golang/mock/issues/416).
