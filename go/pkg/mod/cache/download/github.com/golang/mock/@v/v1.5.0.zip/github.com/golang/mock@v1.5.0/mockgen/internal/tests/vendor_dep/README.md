# Vendor Dep

Test for [Issue#4](https://github.com/golang/mock/issues/4).
Also see discussion on [#28](https://github.com/golang/mock/pull/28).
